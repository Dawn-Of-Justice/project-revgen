%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-09-06T23:58:44+05:30*%
%TF.ProjectId,remote,72656d6f-7465-42e6-9b69-6361645f7063,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-09-06 23:58:44*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.228600X-0.987400X-0.533400X0.987400X-0.533400X0.987400X0.533400X-0.987400X0.533400X0*%
G04 APERTURE END LIST*
D10*
%TO.C,J3*%
X122545000Y-53380000D03*
X122545000Y-55920000D03*
X122545000Y-58460000D03*
X122545000Y-61000000D03*
X122545000Y-63540000D03*
X122545000Y-66079999D03*
X122545000Y-68620000D03*
%TD*%
%TO.C,J4*%
X139455000Y-68620000D03*
X139455000Y-66080000D03*
X139455000Y-63540000D03*
X139455000Y-61000000D03*
X139455000Y-58460000D03*
X139455000Y-55920001D03*
X139455000Y-53380000D03*
%TD*%
M02*
